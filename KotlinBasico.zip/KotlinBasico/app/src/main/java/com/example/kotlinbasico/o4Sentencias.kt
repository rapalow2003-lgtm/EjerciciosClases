package com.example.kotlinbasico

fun main() {
    println("Sentencias y Condicionales")
    println("a:")
    val a = readln().toInt()
    print("b:")
    val b = readln().toInt()

    println("Sentencia if")
    if (false)
        println("La sentencia se cumplio")
    else
        println("La sentencia no se cumplio")

    println("Sentencia if else")

    var comparacion= (a<b)

    if (comparacion)
        println("a es menor que b")
    else
        println("a es mayor que")

    if ((a<b))
        println("a es menor que b")
    else
        println("a es mayor que b")

    println("Sentencia if else if")
    if(comparacion)
        println("comparacion")
    else if (a==b)
        println("no usa comparacion")
    else
        println(comparacion)

    println("Sentencia when")
    println("Ingresa tu nombre para ver tu salario")
    val nombre=readln()
    when(nombre){
        "Lucas"-> println("Tu salario es de 100,000.00")
        "Walter"-> println("Tu salario es de 200,000.00")
        "Jair"-> println("Tu salario es de 500,000.00")
        "Marielos"->{
            println("Tu salario es de 400,000.00")
            println("Tu bonificacion es de 100,000.00")
            println("Tu salario es de 500,000.00")
        }
    }

}//main