package com.example.kotlinbasico

fun main(){

    println("Operadores Elvis")
//
    var version: Int?=3
    println("Las version actual de Android es: $version")
    version=null
    println("Las version actual de Android es: $version")
    println("Las version actual de Android es: ${version?:-15}")


    println("Operadores Aritmeticos")
    println("Ingresa el primer numero: ")
    var num1=readln().toInt()
    println("Ingresa el seundo numero: ")
    var num2=readln().toInt()
    println("La suma es: ${num1+num2}")


//    println("Operadores de Incremento")
//    var x: Int = 10
//    var xmas =--x <>
//    var xmenos= x-- 2
//    println(xmas)
//    println(xmenos)

//
    println("Operadores de igualdad")
    var esIgual: Boolean =(3==1)
    println(esIgual)
    esIgual=(3!=3)
    println(esIgual)

    println("operadores logicos")
    val valor0=(1==1 || 1==5)
    println("or :$valor0")

    val valorY=(1==1 && 1==5)
    println("and: $valorY")

    val valorMenorIgualque=(1<2)
    println("menor que :$valorMenorIgualque")



}// main