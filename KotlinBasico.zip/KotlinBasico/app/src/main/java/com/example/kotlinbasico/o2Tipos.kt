package com.example.kotlinbasico

fun main(){

    //VARIABLES BOOLEANAS
    val soyPatepluma=false
    println("Soy patepluma? $soyPatepluma")

    println("Numeros Enteros")
    var entero: Int=130


    val milisegundos: Long = 1_474_836-471L
    println("Valor de la variable milisegundos: $milisegundos")


    println("Numeros Decimales")
    val pi: Float =3.1416F
    println("Valor de la variable pi : $pi")

    println("Cadenas de caracteres")
    val nombre: String = "Carlos"
    println("Valor de la variable nombre: $nombre")
    val casosEspeciales: String = "Hola, soy \\n\" Carlos"
    println(": $casosEspeciales")

    println("Concatenacion")
    val nombreCompleto=readln()
    println("Hola $nombreCompleto")
    println("Hola "+nombreCompleto)

    println("NULABILIDAD")
    var sobreNombre: String?=null
    sobreNombre="Macaco"
    println("La longitud de la variable sobreNombre es ${sobreNombre.length}")
    sobreNombre=null
    println("La longitud de la variable sobreNombre es ${sobreNombre?.length}")

// !! jamas puede ser nulo
// ? va a ser nulo
}