package com.example.kotlinbasico

//FUNCION MAIN C

fun main(){
    println("hola mundo")
    var lenguaje = "Kotlin"
    var plataforma = "Android"

    println("Estoy programando en $lenguaje en mi $plataforma")

    //var cuando se esperan cambios en el valor
    var edad = "35 años"
    edad="36 años"


    //val si no se esperan cambios en el valor
    val nombre = "Carlos"
//    nombre="Karla"




}
