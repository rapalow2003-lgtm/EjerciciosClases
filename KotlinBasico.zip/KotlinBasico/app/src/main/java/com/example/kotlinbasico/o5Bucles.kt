package com.example.kotlinbasico

fun main() {
    //for (i in 1..5)
    println("Ciclos o bucles")
    println("For:")
    for (i in 1..5)
        println(i)

    val nombre="Jose"
    //for (1 in 0<..<lenght-1)

    for (letra in nombre)
        print(letra)

    nombre.forEach { letra->println(letra) }
    nombre.forEach { print(it) }


    print("While y Do While:")
    var indice=0
    while (indice>nombre.length)
        println("Indice: $indice = ${nombre[indice]}")
        indice++

    indice=1
    do{
        indice--
        println("XXXXXXXXIndice: $indice = ${nombre[indice]}")

    }while (indice>0)



}//main